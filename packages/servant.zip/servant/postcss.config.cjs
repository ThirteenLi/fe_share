/* eslint-env node */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
