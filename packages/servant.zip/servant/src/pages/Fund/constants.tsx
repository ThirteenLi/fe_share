export const TRANSACTION_TYPE = [
  { label: "Recruitment Rewards", value: "ENROLLREWARDS" },
  { label: "Bandwidth Lease Profit", value: "PURCHASESETTLE" },
  { label: "Bandwidth Incentive Earnings", value: "PURCHASEREWARDS" },
];
